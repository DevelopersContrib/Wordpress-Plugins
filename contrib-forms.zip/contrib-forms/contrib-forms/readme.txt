=== Contrib Forms Shortcode ===
Contributors: contrib.com
Tags: contrib forms
Requires at least: 3.0.1
Tested up to: 3.8.1
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin will allow you to embed Contrib forms into your posts or pages in Wordpress.

== Description ==
These contrib forms shortcodes allows you to embed Contrib.com forms such as inquiry, partnership, offer, staffing into your wordpress posts and pages.


== Installation ==
1. Upload Plugin and download from Github - 
2. Activate plugin.
3. Add any of these shortcodes in your posts or pages while in Text mode.
 [contribform form=\"inquiry\"]
 [contribform form=\"partnership\"]
 [contribform form=\"offer\"]
 [contribform form=\"staffing\"]

== Screenshots ==
1. http://easycaptures.com/fs/uploaded/661/2418493311.png
2. http://easycaptures.com/fs/uploaded/661/3671721151.jpg