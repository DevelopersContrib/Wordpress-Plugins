<?php
/**
 * Plugin Name: Socialsuite
 * Plugin URI: 
 * Description: Socialsuite Plugin
 * Version: 1.0.0
 * Author: Contrib.com
 * Author URI: 
 */
 
class Socialsuite {
	private static $instance;
	
	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new Socialsuite();
		} 
		return self::$instance;
	}
	
	private function __construct() {
		
		add_action( 'wp_ajax_updateauthor', array($this,'updateauthor' ));
		add_action('admin_menu', array($this,'socialsuite_main_menu'));
				
		add_action( 'wp_ajax_wpcreatepost', array($this,'wpcreatepost' ));
		add_action( 'wp_ajax_nopriv_wpcreatepost', array($this,'wpcreatepost' ));
		
		add_action( 'wp_ajax_getlatestposts', array($this,'getlatestposts' ));
		add_action( 'wp_ajax_nopriv_getlatestposts', array($this,'getlatestposts' ));
	}

	public function getlatestposts()
	{
		global $wpdb, $table_prefix;	
		$limit = $_REQUEST['limit'];
		if(!empty($limit)){
			$limit = " LIMIT $limit ";
		}
		$sql = "SELECT * ".
		"FROM ".$table_prefix."posts WHERE post_type='post' and post_status ='publish' order by post_date desc $limit ";
		$items = $wpdb->get_results( $sql, ARRAY_A );
		$data = array();
		foreach($items as $item){
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( $item['ID'] ), 'single-post-thumbnail' );
			$image = $image[0];
			$recent_author = get_user_by( 'ID', $item["post_author"] );
			$author_display_name = $recent_author->display_name;
			
			$content = preg_replace("/<img[^>]+\>/i", " ", $item['post_content']);          
			$content = apply_filters('the_content', $content);
			$content = str_replace(']]>', ']]>', $content);
			$content = strip_shortcodes($content);
			
			$data[] = array(
				"ID"=>$item['ID'],
				"post_title"=>$item['post_title'],
				"post_content"=>$content,
				"post_date"=>$item['post_date'],
				"url"=>get_permalink($item['ID']),
				"image_url"=>$image,
				"author"=>$author_display_name
			);
		}
		echo json_encode($data);
		die();
	}

	public function wpcreatepost(){
		$title = $_POST['title'];
		$content = $_POST['content'];
		$userid = get_option( 'socialsuite_author' );
		
		if(empty($title)){
			echo 'Post title is required';
			die();
		}else if(empty($content)){
			echo 'Post content is required';
			die();
		}else if(empty($userid)){
			echo 'Socialsuite author has not been setup.';
			die();
		}
		
		$my_post = array(
			  'post_title'    => wp_strip_all_tags($title ),
			  'post_content'  => $content,
			  'post_status'   => 'publish',
			  'post_author'   => $userid,
			  'post_type'     => 'post',
		);
		$pid = wp_insert_post( $my_post );
		echo $pid;
		die();
	}

	public function updateauthor() {
		if(!empty($_POST['author'])){
			update_option( 'socialsuite_author', $_POST['author'] );
		}
	}


	public function socialsuite_main_menu() {
		add_menu_page(__('Socialsuite'), __('Socialsuite'), 'read', 'socialsuite_main_menu', array($this,'socialsuite_main_page'), '', 7);
	}
		
	public function socialsuite_main_page(){
		$socialsuite_activate_contact_page = get_option( 'activate_socialsuite' );
	?>
	
	<style>
		@import url("https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css");
		/* 1 column: 320px */
		.Socialsuite-custom-plugin {
		  margin: 0px auto 0;
			width: 98%;
		   font-family:arial !important;
		}
		
		/* 2 columns: 600px */
		@media only screen and (min-width: 600px) {
		  .Socialsuite-custom-plugin .vcp-module {
				float: left;
				margin-right: 2.564102564102564%;
				width: 48.717948717948715%;
			}
			.Socialsuite-custom-plugin .vcp-module:nth-child(2n+0) {
				margin-right: 0;
			}
		}
		/* 3 columns: 768px */
		@media only screen and (min-width: 768px) {
		  .Socialsuite-custom-plugin .vcp-module {
				width: 31.623931623931625%;
			}
			.Socialsuite-custom-plugin .vcp-module:nth-child(2n+0) {
				margin-right: 2.564102564102564%;
			}
			.Socialsuite-custom-plugin .vcp-module:nth-child(3n+0) {
				margin-right: 0;
			}
		}
		/* 4 columns: 992px and up */
		@media only screen and (min-width: 992px) {
		  .Socialsuite-custom-plugin .vcp-module {
				width: 23.076923076923077%;
			}
			.Socialsuite-custom-plugin .vcp-module:nth-child(3n+0) {
				margin-right: 2.564102564102564%;
			}
			.Socialsuite-custom-plugin .vcp-module:nth-child(4n+0) {
				margin-right: 0;
			}
		}

		/***** tabs ******/
		.Socialsuite-custom-plugin .clear-section {
		   clear:both;
		}
		.vcp-tab-main {
		  width: auto;
		  min-width: 320px;
		  padding: 20px 0px 50px;
		  margin: 0 auto;
		  background: #fff;
		}

		.vcp-tab-main section {
		  display: none;
		  padding: 20px 15px 20px;
		  border: 1px solid #ddd;
		}

		.vcp-tab-main input {
		  display: none;
		}

		.vcp-tab-main label {
		  display: inline-block;
		  margin: 0 0 -1px;
		  padding: 15px 25px;
		  font-weight: 600;
		  text-align: center;
		  color: #bbb;
		  border: 1px solid transparent;
		}

		.vcp-tab-main label:before {
		  font-family: arial;
		  font-weight: normal;
		  margin-right: 10px;
		}

		.vcp-tab-main label:hover {
		  color: #888;
		  cursor: pointer;
		}

		.vcp-tab-main input:checked + label {
		  color: #555;
		  border: 1px solid #ddd;
		  border-top: 2px solid orange;
		  border-bottom: 1px solid #fff;
		}

		.vcp-tab-main #tab1:checked ~ #content1,
		.vcp-tab-main #tab2:checked ~ #content2,
		.vcp-tab-main #tab3:checked ~ #content3,
		.vcp-tab-main #tab4:checked ~ #content4 {
		  display: block;
		}

		@media screen and (max-width: 650px) {
		  .vcp-tab-main label {
			font-size: 0;
		  }
		  .vcp-tab-main label:before {
			margin: 0;
			font-size: 18px;
		  }
		}

		@media screen and (max-width: 400px) {
		  .vcp-tab-main label {
			padding: 15px;
		  }
		}
		.vcp-tab-main .vtab {
		   padding: 0px 20px 20px 20px;
		}
		.vcp-tab-main .vtab h3 {
		   font-size: 16px;
		   border-bottom: 1px dashed #ddd;
		   padding-bottom: 10px;
		   margin-bottom: 10px;
		}
		
		.vtab .mpages .mpages-in {
		   background: #fafafa;
		   border: 1px solid #ddd;
		   padding: 10px 10px 20px 10px;
		   margin-bottom: 25px;
		   border-radius: 3px;
		}
		.logo-img-ss{
			display: inline-block;
			max-width: 100%;
			height: auto;
		}
		.vtop-inline li{
			vertical-align: middle;
		}
		h3.ttle-block{color: #666;letter-spacing: 0.5px;}
		.wrap-box-form{margin-top:10px;margin-bottom:20px;padding:30px;display:inline-block;}
		.meta-ht {
    background-color: #e7505a;
    border-radius: 5px;
    color: #fff;
    display: inline-block;
    font-size: 12px;
    font-weight: 800;
    letter-spacing: 0.1px;
    line-height: normal;
    padding: 5px 10px;
    text-decoration: none;
    text-transform: uppercase;
}
.meta-ht:hover{text-decoration: none;color: #fff;}
		</style>

		<div class="Socialsuite-custom-plugin">
		   <!-- tab section -->
		   <div class="clear-section"></div>
		   <div class="vcp-tab-main">
			 <input id="tab1" type="radio" name="tabs" checked="">
			 <label id="lcustomfooter" for="tab1">Socialsuite Settings</label>

			 <section id="content1">
				<div class="vtab">
				   <div class="row">
					<div class="col-md-12 text-center">
						<a href="http://socialsuite.com/">
							<img class="logo-img-ss" height="90" width="200" src="http://socialsuite.com/assets/img/1479789565.png">
						</a>
						<h1>Is a Plugin for Socialsuite</h1>
					</div>
				   	<div class="col-md-12 text-center">
						<div class="wrap-box-form">
						<a href="http://blog.socialsuite.com/knowledge-base" class="meta-ht">How to?</a>
						<h3 class="ttle-block">Choose the author from the posts you wish to publish from socialsuite:</h3>
						<ul class="list-inline vtop-inline">
							<li><span>Post Author: </span></li>
							<li>
								<select id="post-author">
							<option value="">Select Author</option>
							<?php
								$blogusers = get_users('orderby=display_name&order=ASC');
								$users = array();
								$socialsuite_author = get_option( 'socialsuite_author' );
								foreach($blogusers as $user){
							?>
							<option <?=$socialsuite_author==$user->ID?'SELECTED':''?>  value="<?=$user->ID?>"><?=$user->display_name?></option>
							<?php
								}
							?>
						</select>
							</li>
							<li><a  href="javascript:;" class="btn btn-primary btn-update-author">Update</a></li>
						</ul>
						</div>
						
					 	
					 	<script type="text/javascript">
							jQuery(document).ready(function(){									
								jQuery('.btn-update-author').click(function(){
									var parent = jQuery(this).parent();
									var b = jQuery(this);
									b.attr('disabled', 'disabled').html("Updating...");
									jQuery.post(
									"<?=get_site_url()?>/wp-admin/admin-ajax.php", 
									{
										action: 'updateauthor',
										author: jQuery('#post-author').val(),
									}, 
									function(response){
										b.removeAttr('disabled').html('Update');
									}
								);
							});
						});
						</script>
					</div>
				   </div>
				</div>
			 </section>
		  </div>
		   <!-- end tab-->
		</div>
		<br style="clear:both;">
	<?php
	}
}

add_action( 'plugins_loaded', array( 'Socialsuite', 'get_instance' ) );

//add_action('wp_loaded', array( 'Socialsuite', 'addpage' ));

