<?php
/*
Plugin Name: Contrib Sidebar Widget
Plugin URI:
Description: Integrates contrib widget that will allow users to contribute time, content, distribution, apps.
Author: Contrib.com
Version: 1
Network: true
Author URI: Contrib.com
*/

add_action('init','init_sidebar_contrib_widget');

function init_sidebar_contrib_widget(){
    if(is_admin()){
		add_action('admin_menu', 'sidebar_contrib_menu');
		function sidebar_contrib_menu() {
			add_menu_page(__('Contrib Sidebar Widget'), __('Contrib Sidebar Widget'), 'read', 'sidebar_contrib_menu', 'sidebar_contrib', '', 7);
		}
    }
	$activate_sidebar_contrib_widget = get_option('activate_sidebar_contrib_widget');
	if(!empty($activate_sidebar_contrib_widget)){
		function do_sidebar_contrib_widget(){
		   echo ' <script src="https://tools.contrib.com/cwidget?d='.$_SERVER['SERVER_NAME'].'&p=sb&c=f"></script>  ';
		}
		add_action('wp_footer', 'do_sidebar_contrib_widget');
	}
}



function sidebar_contrib(){
		if(isset($_POST['save'])){
			$deprecated = null;
			$autoload = 'no';
			$activate_sidebar_contrib_widget = !empty($_POST['activate_sidebar_contrib_widget'])?1:'';
			
			if ( get_option( 'activate_sidebar_contrib_widget' ) !== false ) add_option( 'activate_sidebar_contrib_widget', $activate_sidebar_contrib_widget, $deprecated, $autoload );
			
			update_option( 'activate_sidebar_contrib_widget', $activate_sidebar_contrib_widget );
		}
		
		$activate_sidebar_contrib_widget = get_option('activate_sidebar_contrib_widget');
	?>
		<div class="row">
			<div class="col-md-12">
				<h3 class="text-capitalize">Contrib Sidebar Widget Widget</h3>
				<hr>
				<div class="media">
					<div style="float:left;margin-right:10px">
						<img alt="" src="https://s3.amazonaws.com/assets.zipsite.net/images/lucille/sidebar-contrib-widget.png" class="media-object img-rounded mo-img-prev">
					</div>
					<div style="float:left;margin-bottom:20px">
						<p>
								This widget allows you to share your brands needs to your visitors.												</p>
							<a target="_blank" href="http://contrib.applications.com/apps/details/m/cwsidebar" class="btn btn-primary">
							<b>View More</b>
						</a>	
					<br><br>
					<p style="padding:10px;" class="text-muted">The Sharing Sidebar is the easiest way to increase sharing up to 2x over regular sharing buttons. It floats over the side of your page and automatically shows visitors the right sharing buttons for them.</p>
					<div class="col-lg-6 col-lg-offset-3">
						<h3>Preview image: </h3>
						<div class="wrap-prvw-modalContainer">
							<img class="img-responsive" data-hover="https://d2qcctj8epnr7y.cloudfront.net/images/lucille/animation-mid.gif" src="https://d2qcctj8epnr7y.cloudfront.net/images/lucille/thumb-mid-right.png">
						</div>
						</div>
					<form id="frm_activate_sidebar_contrib_widget" method="post" action="">
						<input <?=!empty($activate_sidebar_contrib_widget)?'checked':'';?> type="checkbox" name="activate_sidebar_contrib_widget" id="activate_sidebar_contrib_widget" />
						<input type="hidden" name="save" id="save" value="1">
						<b>Activate</b>
					</form>
					<script type="text/javascript">
					var form = document.getElementById("frm_activate_sidebar_contrib_widget");

					document.getElementById("activate_sidebar_contrib_widget").addEventListener("click", function () {
					  form.submit();
					});
					</script>
					</div>					
				</div>
			</div>
		</div>
	<?php
}
function contrib_sidebar_script($atts, $content = null) {
	$html = '<script type="text/javascript" src="https://www.contrib.com/widgets?ma=sidebar"></script>';
	return $html;
}
?>