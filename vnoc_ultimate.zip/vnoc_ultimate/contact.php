<?php get_header(); ?>
<style>
#content-footer-section {
    display: none;
}
.return-container {
   margin-top:20px;
   margin-bottom: 40px;
}
.pc-box {
    background: #fafafa;
    padding: 80px 30px 100px 30px;
    margin-bottom: 50px;
}
</style>

<div class="container">
   <div class="row">
      <div class="col-md-12 text-center return-container">
         <a href="/" class="btn btn-primary btn-lg">Return to Hompage</a>
      </div>
      <hr>
      <div class="col-md-12">
         <h3 class="ptitle text-center">
            Contact Us
         </h3>
      </div>
      <div class="col-md-8 col-md-offset-2 pc-box">
         <script type="text/javascript" src="http://tools.contrib.com/contactform?d=<?=$_SERVER['HTTP_HOST']?>"></script>
      </div>
   </div>
</div>
<?php get_footer(); ?>
