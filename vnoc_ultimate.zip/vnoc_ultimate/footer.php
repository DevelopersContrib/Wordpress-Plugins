<style>
@import url("https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css");
.rsrc-footer {
    display: none !important;
}
.footer1 {
   background: #333;
   color: #fff;
   padding: 20px 0px 30px;
   font-size: 13px;
}
.footer1 a {
   font-size: 13px;
   color: #999;
}
.footer1 .widget ul {
    padding-left: 0px;
}
.footer1 h3 {
   color:#fff !important;
}
.footer1 .fa {
   font-size: 30px;
}
.footer2 {
   background: #222;
   padding: 15px 0px 1px;
   font-size: 13px;
}
.footer2 a {
   font-size: 13px;
   color: #999;
}
</style>
<footer id="footer" class="ts">
   <div class="footer1">
	  <div class="container">
		 <div class="row">
			<div class="col-md-3 widget">
			   <h3 class="widget-title">[domain]</h3>
			   <div class="widget-body">
				  <p>
					 Join our exclusive community of like minded people on [domain]
				  </p>
			   </div>
			</div>

			<div class="col-md-3 widget">
			   <h3 class="widget-title">Get Started</h3>
			   <div class="widget-body">
				  <ul class="list-unstyled">
					 <li><a href="/partner">Partner With Us</a></li>
					 <li><a href="/staffing">Apply Now</a></li>
					 <li><a href="/referral">Referral</a></li>
					 <li><a href="/developers">Developers</a></li>
				  </ul>
			   </div>
			</div>

			<div class="col-md-3 widget">
			   <h3 class="widget-title">Company</h3>
			   <div class="widget-body">
				  <ul class="list-unstyled">
					 <li><a href="/about">About Us</a></li>
					 <li><a href="/terms">Terms</a></li>
					 <li><a href="/privacy">Privacy</a></li>
					 <li><a href="/contact">Contact Us</a></li>
				  </ul>
			   </div>
			</div>

			<div class="col-md-3 widget">
			   <h3 class="widget-title">Follow me</h3>
			   <div class="widget-body">
				  <p class="follow-me-icons">
					
					 <a href="followme_twitter"><i class="fa fa-twitter fa-2"></i></a>
					 <!--<a href="javascript:;"><i class="fa fa-dribbble fa-2"></i></a>-->
					 <a href="followme_facebook"><i class="fa fa-github fa-2"></i></a>
					 <a href="followme_github"><i class="fa fa-facebook fa-2"></i></a>
				  </p>
			   </div>
			</div>

		 </div> <!-- /row of widgets -->
	  </div>
   </div>

   <div class="footer2">
	  <div class="container">
		 <div class="row">

			<div class="col-md-6 widget">
			   <div class="widget-body">
				  <p class="simplenav">
					 <a href="/about">About Us</a> |
					 <a href="/terms">Terms</a> |
					 <a href="/privacy">Privacy</a> |
					 <b><a href="/contact">Contact Us</a></b>
				  </p>
			   </div>
			</div>

			<div class="col-md-6 widget">
			   <div class="widget-body">
				  <p class="text-right">
					 Copyright &copy; 2016 <a href="/" rel="designer">Streaming.net</a>
				  </p>
			   </div>
			</div>

		 </div> <!-- /row of widgets -->
	  </div>
   </div>
</footer>