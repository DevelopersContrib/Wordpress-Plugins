<?php get_header(); ?>
<style>
#content-footer-section {
    display: none;
}
.return-container {
   margin-top:20px;
   margin-bottom: 40px;
}
.pc-box {
    background: #fafafa;
    padding: 30px 30px 50px 30px;
    margin-bottom: 50px;
}
.blur-box {
   border-bottom: 1px solid #fff;
   margin-bottom: 10px;
   margin-top: 10px;
}
.pc-box h3 {
	margin-top: 0px;
}
</style>

<div class="container">
   <div class="row">
      <div class="col-md-12 text-center return-container">
         <a href="/" class="btn btn-primary btn-lg">Return to Hompage</a>
      </div>
      <hr>
      <div class="col-md-12">
         <h3 class="ptitle text-center">
            Partner With Us
         </h3>
      </div>
      <div class="col-md-8 col-md-offset-2 pc-box">
			<div class="blur-box text-left">
				  <div class="row">
						<div class="col-sm-4">
							 <a href="http://www.contrib.com">
								  <img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-174x35.png" alt="Partner" title="Partner">
							 </a>
						</div>
						<div class="col-sm-8">
							 <h3>
								  <a href="http://www.contrib.com">Contrib.com</a>
							 </h3>
							 <p>
								  We are a community of Entrepreneurs, Developers, Designers, Marketers and Specialists from around the world building, managing and monetizing virtual businesses on premium domains for equity and cash grants.                                        </p>
						</div>
				  </div>
			 </div>
			<div class="blur-box text-left">
				  <div class="row">
						<div class="col-sm-4">
							 <a href="http://globalventures.com">
								  <img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png" alt="Partner" title="Partner">
							 </a>
						</div>
						<div class="col-sm-8">
							 <h3>
								  <a href="http://globalventures.com">GlobalVentures.com</a>
							 </h3>
							 <p>
								  With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.                                        </p>
						</div>
				  </div>
			 </div>

			  <div class="blur-box text-left">
					<div class="row">
						 <div class="col-sm-4">
							  <a href="http://ifund.com">
									<img class="img-responsive" src="http://www.contrib.com/uploads/logo/ifund.png" alt="iFund.com" title="iFund.com">
							  </a>
						 </div>
						 <div class="col-sm-8">
							  <h3>
									<a href="http://ifund.com">iFund.com</a>
							  </h3>
							  <p>
									iFund is a software as a service crowdfunding platform. iFund is not a registered broker-dealer and does not offer investment
									advice or advise on the raising of capital through securities offerings. iFund does not recommend or otherwise suggest that any
									investor make an investment in a particular company, or that any company offer securities to a particular investor. iFund takes no part in the negotiation or execution of transactions for the purchase or sale of securities, and at no time has possession of funds or securities. No securities transactions are executed or negotiated on or through the iFund platform.
									iFund receives no compensation in connection with the purchase or sale of securities.
							  </p>
						 </div>
					</div>
			  </div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://ichallenge.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-ichallenge1.png" alt="iChallenge.com" title="iChallenge.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://ichallenge.com">iChallenge.com</a>
									  </h3>
									  <p>
											 The best internet challenges. Solve and win online prizes.
									  </p>
								 </div>
							</div>
				</div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://socialid.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-socialid1.png" alt="Socialid.com" title="Socialid.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://socialid.com">SocialId.com</a>
									  </h3>
									  <p>
											 SocialId helps you get the social name for all major social networking websites.
									  </p>
								 </div>
							</div>
				</div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://virtualinterns.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png" alt="Virtualinterns.com" title="Virtualinterns.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://virtualinterns.com">Virtualinterns.com</a>
									  </h3>
									  <p>
											  Join our exclusive community of like minded people on virtualinterns.com
									  </p>
								 </div>
							</div>
				</div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://referrals.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-referrals-beta.png" alt="Referrals.com" title="Referrals.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://referrals.com">Referrals.com</a>
									  </h3>
									  <p>
											  Most effective Business Referral Program and Tools Available. Find and share referrals locally.
									  </p>
								 </div>
							</div>
					  </div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://adrate.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-adrate-3.png" alt="Adrate.com" title="Adrate.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://adrate.com">Adrate.com</a>
									  </h3>
									  <p>
										  Insightful Ad Content Direct To Your Target Market Advertising That Will Reach. Attract. Target. & Engage Your Future Customers
									  </p>
								 </div>
							</div>
					  </div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://consultants.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png" alt="Consultants.com" title="Consultants.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://consultants.com">Consultants.com</a>
									  </h3>
									  <p>
											 Find a consultant using our global directory. Request a proposal and get quotes. Or are you looking for consulting jobs? See available job openings. Create your consultant profile and get badges for your consultancy.
									  </p>
								 </div>
							</div>
					  </div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://domaindirectory.com">
											<img class="img-responsive" src="http://www.domaindirectory.com/images/logo-domaindirectory300x82.png" alt="Domaindirectory.com" title="Domaindirectory.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://domaindirectory.com">Domaindirectory.com</a>
									  </h3>
									  <p>
												Domain Directory - Buy, Sell, Trade, Develop, Partner with premium domains on the Domain Directory platform.
									  </p>
								 </div>
							</div>
					  </div>
				<div class="blur-box text-left">
							<div class="row">
								 <div class="col-sm-4">
									  <a href="http://handyman.com">
											<img class="img-responsive" src="http://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png" alt="Handyman.com" title="Handyman.com">
									  </a>
								 </div>
								 <div class="col-sm-8">
									  <h3>
											<a href="http://handyman.com">Handyman.com</a>
									  </h3>
									  <p>
											 Handyman.com is the best place to find a professional contractor.
									  </p>
								 </div>
							</div>
				</div>
      </div>
   </div>
</div>
<?php get_footer(); ?>
