<?php
/*
Plugin Name: VNOC Ultimate WP Plugin
Plugin URI: 
Version: 1.0
Author: 
Author 
*/

class VNOCUltimate {
	private static $instance;
	protected $templates;
	
	public static function get_instance() {
		if ( null == self::$instance ) {
			self::$instance = new VNOCUltimate();
		} 
		return self::$instance;
	}
	
	private function __construct() {
		$this->templates = array();
		add_filter(
			'page_attributes_dropdown_pages_args',
			array( $this, 'register_vnoc_page_templates' ) 
		);
		add_filter(
			'wp_insert_post_data', 
			array( $this, 'register_vnoc_page_templates' ) 
		);
		add_filter(
			'template_include', 
			array( $this, 'view_vnoc_page_template') 
		);
		$this->templates = array(
			'contact.php' => 'Contact',
			'developers.php' => 'Developers',
			'partner.php' => 'Partners',
			'privacy.php' => 'Privacy',
			'referral.php' => 'Referral',
			'staffing.php' => 'Staffing',
			'terms.php' => 'Terms',
			'about.php' => 'About',
		);
		
		
		add_action( 'wp_ajax_savepage', array($this,'savepage' ));
		add_action( 'wp_ajax_activateuppersidebarwidget', array($this,'activateuppersidebarwidget' ));
		add_action( 'wp_ajax_activatesidebarwidget', array($this,'activatesidebarwidget' ));
	
		add_action('admin_menu', array($this,'vnoc_main_menu'));
		
		add_shortcode( 'contrib_live_rep', array($this,'contrib_live_rep_script' ));
		
		add_shortcode( 'lead_contrib_widget_black', array($this,'lead_contrib_widget_black_script' ));
		add_shortcode( 'lead_contrib_widget_gray', array($this,'lead_contrib_widget_gray_script' ));
		
		add_shortcode( 'contrib_micronews', array($this,'contrib_micronews_script' ));
		
		add_shortcode( 'contrib_rating', array($this,'contrib_rating_script' ));
		
		add_shortcode( 'contrib_footer', array($this,'contrib_footer_content' ));
		
		
		$activate_sidebar_contrib_widget = get_option('activate_sidebar_contrib_widget');
		if(!empty($activate_sidebar_contrib_widget)){
			add_action('wp_footer', array($this,'do_sidebar_contrib_widget'));
		}

		$activate_upper_right_contrib_widget = get_option('activate_upper_right_contrib_widget');
		if(!empty($activate_upper_right_contrib_widget)){
			add_action('wp_footer', array($this,'do_upper_right_contrib_widget'));
		}
		
		add_action('wp_head', array($this,'jquery_no_conflict'));
	}
	
	public function activateuppersidebarwidget()
	{
		$deprecated = null;
		$autoload = 'no';
		$activate_upper_right_contrib_widget = $_POST['value'];
		
		if ( get_option( 'activate_upper_right_contrib_widget' ) !== false ) add_option( 'activate_upper_right_contrib_widget', $activate_upper_right_contrib_widget, $deprecated, $autoload );
		
		update_option( 'activate_upper_right_contrib_widget', $activate_upper_right_contrib_widget );
	}
	
	public function activatesidebarwidget()
	{	
		$deprecated = null;
		$autoload = 'no';
		$activate_sidebar_contrib_widget = $_POST['value'];
		
		if ( get_option( 'activate_sidebar_contrib_widget' ) !== false ) add_option( 'activate_sidebar_contrib_widget', $activate_sidebar_contrib_widget, $deprecated, $autoload );

		update_option( 'activate_sidebar_contrib_widget', $activate_sidebar_contrib_widget );
	}
	
	
	public function savepage() {
		$return = '';
		if(isset($_POST['page'])){
			switch($_POST['page']){
				case 'contact':
					$return = $this->set_page('Contact','contact','contact.php',$_POST['add']);
				break;
				case 'developers':
					$return = $this->set_page('Developers','developers','developers.php',$_POST['add']);
				break;
				case 'partner':
					$return = $this->set_page('Partner','partner','partner.php',$_POST['add']);
				break;
				case 'privacy':
					$return = $this->set_page('Privacy','privacy','privacy.php',$_POST['add']);
				break;
				case 'referral':
					$return = $this->set_page('Referral','referral','referral.php',$_POST['add']);
				break;
				case 'staffing':
					$return = $this->set_page('Staffing','staffing','staffing.php',$_POST['add']);
				break;
				case 'terms':
					$return = $this->set_page('Terms','terms','terms.php',$_POST['add']);
				break;
				case 'about':
					$return = $this->set_page('About','about','about.php',$_POST['add']);
				break;
			}
		}
		
		if(!empty($return)){
			$return = get_permalink($return);
		}
		die($return);
	}

		
	public function register_vnoc_page_templates( $atts ) {
		$cache_key = 'page_templates-' . md5( get_theme_root() . '/' . get_stylesheet() );

		$templates = wp_get_theme()->get_page_templates();
		if ( empty( $templates ) ) {
			$templates = array();
		} 
		wp_cache_delete( $cache_key , 'themes');

		$templates = array_merge( $templates, $this->templates );
		wp_cache_add( $cache_key, $templates, 'themes', 1800 );
		return $atts;
	}

	public function view_vnoc_page_template( $template ) {
		global $post;
		if ( ! $post ) {
			return $template;
		}

		if ( !isset( $this->templates[get_post_meta( 
			$post->ID, '_wp_page_template', true 
		)] ) ) {
			return $template;
		} 

		$file = plugin_dir_path(__FILE__). get_post_meta( 
			$post->ID, '_wp_page_template', true
		);

		if ( file_exists( $file ) ) {
			return $file;
		} else {
			echo $file;
		}
		return $template;
	}

	public function vnoc_main_menu() {
		add_menu_page(__('VNOC Ultimate WP Plugin'), __('VNOC Ultimate WP Plugin'), 'read', 'vnoc_main_menu', array($this,'vnoc_main_page'), '', 7);
	}
	
	public function set_page($page_title, $slug, $page_file,$add)
	{
		$page_id = 0;
		$deprecated = null;
		$autoload = 'no';
		
		$activate_page = !empty($add)?1:'';
		
		if(!empty($activate_page)){
			$page_id = $this->create_pages($page_title, $slug, $page_file);
		}else{
			if ( get_option( 'activate_'.$slug.'_page_id' ) !== false ){
				wp_delete_post( get_option( 'activate_'.$slug.'_page_id' ), true);
			}
		}
		
		if ( get_option( 'activate_'.$slug.'_page' ) !== false ){			
			add_option( 'activate_'.$slug.'_page', $page_id, $deprecated, $autoload );			
			add_option( 'activate_'.$slug.'_page_id', $page_id, $deprecated, $autoload );
		}

		update_option( 'activate_'.$slug.'_page', $page_id );
		update_option( 'activate_'.$slug.'_page_id', $page_id );
	
		return $page_id;
	}
	
	public function vnoc_main_page(){
		$activate_contact_page = get_option( 'activate_contact_page' );
		$activate_developers_page = get_option( 'activate_developers_page' );
		$activate_partner_page = get_option( 'activate_partner_page' );
		$activate_privacy_page = get_option( 'activate_privacy_page' );
		$activate_referral_page = get_option( 'activate_referral_page' );
		$activate_staffing_page = get_option( 'activate_staffing_page' );
		$activate_terms_page = get_option( 'activate_terms_page' );
		$activate_about_page = get_option( 'activate_about_page' );
		
		$activate_sidebar_contrib_widget = get_option('activate_sidebar_contrib_widget');
		$activate_upper_right_contrib_widget = get_option('activate_upper_right_contrib_widget');

	?>
	
		<style>
		@import url("https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css");
		/* 1 column: 320px */
		.vnoc-custom-plugin {
		  margin: 30px auto 0;
			width: 98%;
		   font-family:arial !important;
		}
		.vnoc-custom-plugin .vcp-module {
		  background-color: fafafa;
		  border-radius: .25rem;
		  margin-bottom: 1rem;
		  text-align: center;
		}
		.vnoc-custom-plugin .vcp-box {
		   padding: 30px;
		   background: #fafafa;
		   border: 1px solid #ddd;
		   border-radius: 3px;
		   display: block;
		   text-decoration: none;
		   color: #121212;
		}
		.vnoc-custom-plugin .vcp-box:hover {
		   border:1px solid #aaa;
		   background: #fff;
		}
		.vnoc-custom-plugin .vcp-box h4 {
		   margin: 0px;
		}
		.vnoc-custom-plugin .vcp-box h3 {
		   margin-top: 10px;
		   color:#666;
		}
		.vnoc-custom-plugin .vcp-box img {
		   width: 80px;
		   height: 80px;
		}
		/* 2 columns: 600px */
		@media only screen and (min-width: 600px) {
		  .vnoc-custom-plugin .vcp-module {
				float: left;
				margin-right: 2.564102564102564%;
				width: 48.717948717948715%;
			}
			.vnoc-custom-plugin .vcp-module:nth-child(2n+0) {
				margin-right: 0;
			}
		}
		/* 3 columns: 768px */
		@media only screen and (min-width: 768px) {
		  .vnoc-custom-plugin .vcp-module {
				width: 31.623931623931625%;
			}
			.vnoc-custom-plugin .vcp-module:nth-child(2n+0) {
				margin-right: 2.564102564102564%;
			}
			.vnoc-custom-plugin .vcp-module:nth-child(3n+0) {
				margin-right: 0;
			}
		}
		/* 4 columns: 992px and up */
		@media only screen and (min-width: 992px) {
		  .vnoc-custom-plugin .vcp-module {
				width: 23.076923076923077%;
			}
			.vnoc-custom-plugin .vcp-module:nth-child(3n+0) {
				margin-right: 2.564102564102564%;
			}
			.vnoc-custom-plugin .vcp-module:nth-child(4n+0) {
				margin-right: 0;
			}
		}

		/***** tabs ******/
		.vnoc-custom-plugin .clear-section {
		   clear:both;
		}
		.vcp-tab-main {
		  width: auto;
		  min-width: 320px;
		  padding: 20px 50px 50px;
		  margin: 0 auto;
		  background: #fff;
		}

		.vcp-tab-main section {
		  display: none;
		  padding: 20px 15px 20px;
		  border: 1px solid #ddd;
		}

		.vcp-tab-main input {
		  display: none;
		}

		.vcp-tab-main label {
		  display: inline-block;
		  margin: 0 0 -1px;
		  padding: 15px 25px;
		  font-weight: 600;
		  text-align: center;
		  color: #bbb;
		  border: 1px solid transparent;
		}

		.vcp-tab-main label:before {
		  font-family: arial;
		  font-weight: normal;
		  margin-right: 10px;
		}

		.vcp-tab-main label:hover {
		  color: #888;
		  cursor: pointer;
		}

		.vcp-tab-main input:checked + label {
		  color: #555;
		  border: 1px solid #ddd;
		  border-top: 2px solid orange;
		  border-bottom: 1px solid #fff;
		}

		.vcp-tab-main #tab1:checked ~ #content1,
		.vcp-tab-main #tab2:checked ~ #content2,
		.vcp-tab-main #tab3:checked ~ #content3,
		.vcp-tab-main #tab4:checked ~ #content4 {
		  display: block;
		}

		@media screen and (max-width: 650px) {
		  .vcp-tab-main label {
			font-size: 0;
		  }
		  .vcp-tab-main label:before {
			margin: 0;
			font-size: 18px;
		  }
		}

		@media screen and (max-width: 400px) {
		  .vcp-tab-main label {
			padding: 15px;
		  }
		}
		.vcp-tab-main .vtab {
		   padding: 0px 20px 20px 20px;
		}
		.vcp-tab-main .vtab h3 {
		   font-size: 16px;
		   border-bottom: 1px dashed #ddd;
		   padding-bottom: 10px;
		   margin-bottom: 10px;
		}
		.vtab .manage-footer-img {
		   width:100%;
		}
		.vcp-footer-container {
		   background: #333;
		   color: #fff;
		   padding: 10px 0px 20px;
		}
		.vcp-footer-container .col-group > div {
		  padding: none;
		}
		.vcp-footer-container .col-group .footer-in {
		   padding: 15px;
		}
		.vcp-footer-container .col-group .footer-in h3 {
		   border:none;
		   text-transform: uppercase;
		   color:#fff;
		}
		.vcp-footer-container .footer-in .v-domain-desc {
		   font-size: 13px;
		}
		.vcp-footer-container .footer-in .p-link {
		   line-height: 6px;
		}
		.vcp-footer-container .footer-in .p-link a {
		   text-decoration:none;
		   color:#999;
		   font-size: 13px;
		}
		.vcp-footer-container .v-socials img {
		   width:40px;
		}
		.vcp-footer-container .col-group .footer-in .p-link a:hover {
		   color:#fff;
		}
		@media screen and (min-width: 44em) {
		  .vcp-footer-container .col-group {
			overflow: hidden;
		  }
		  .vcp-footer-container .col-group > div {
			float: left;
			width: 50%;
		  }
		  .vcp-footer-container .col-group > div:nth-child(odd) {
			clear: left;
		  }
		}
		@media screen and (min-width: 64em) {
		  .vcp-footer-container .col-group > div {
			width: 25%;
		  }
		  .vcp-footer-container .col-group > div:nth-child(odd) {
			clear: none;
		  }
		}

		.vcp-footer-container-bottom {
		   background: #222;
		   color: #fff;
		   padding: 10px 0px 5px;
		   font-size: 13px;
		}
		.vcp-footer-container-bottom p a {
		   color:#999;
		   text-decoration: none;
		   font-size: 13px;
		   margin-right: 5px;
		}
		.vcp-footer-container-bottom p a:hover {
		   color:#fff;
		}
		.vcp-footer-container-bottom .lcol {
		   float:left;
		}
		.vcp-footer-container-bottom .rcol {
		   float:right;
		}
		.scw {
		   margin-bottom: 2px;
		}
		.scw input:checked + label {
			color: #fff;
			border: none;
			padding: 6px;
			background: orange;
		}
		.scw label {
			display: inline-block;
			margin: 0 0 -1px;
			padding: 6px;
			font-weight: 600;
			text-align: center;
			color: #bbb;
			border: none;
			background: #fafafa;
		}
		.vtab .col-md-3, .vtab .col-md-4 {
		   border-bottom: 1px solid #ddd;
		   padding-bottom: 10px;
		   height:560px;
		}
		.vtab .mpages .mpages-in {
		   background: #fafafa;
		   border: 1px solid #ddd;
		   padding: 10px 10px 20px 10px;
		   margin-bottom: 25px;
		   border-radius: 3px;
		}
		</style>

		<div class="vnoc-custom-plugin">
			<div class="vcp-module">
			  <a data-target="#lcustomfooter" href="javascript:;" class="vcp-box">
				 <h3>Custom Footer</h3>
				 <div class="vcp-icon">
					<img src="http://image.flaticon.com/icons/png/512/234/234117.png">
				 </div>
			  </a>
			</div>
		   <div class="vcp-module">
			  <a data-target="#lcustompage" href="javascript:;" class="vcp-box">
				 <h3>Custom Pages</h3>
				 <div class="vcp-icon">
					<img src="http://image.flaticon.com/icons/svg/234/234116.svg">
				 </div>
			  </a>
			</div>
		   <div class="vcp-module">
			  <a data-target="#lcontribwidget" href="javascript:;" class="vcp-box">
				 <h3>Contrib Widgets</h3>
				 <div class="vcp-icon">
					<img src="http://image.flaticon.com/icons/svg/234/234107.svg">
				 </div>
			  </a>
			</div>
		   <div class="vcp-module">
			  <a data-target="#lliverep" href="javascript:;" class="vcp-box">
				 <h3>Live Rep</h3>
				 <div class="vcp-icon">
					<img src="http://image.flaticon.com/icons/png/512/204/204316.png">
				 </div>
			  </a>
			</div>

		   <!-- tab section -->
		   <div class="clear-section"></div>
		   <div class="vcp-tab-main">
			 <input id="tab1" type="radio" name="tabs" checked="">
			 <label id="lcustomfooter" for="tab1">Custom Footer</label>

			 <input id="tab2" type="radio" name="tabs">
			 <label id="lcustompage" for="tab2">Custom Pages</label>

			 <input id="tab3" type="radio" name="tabs">
			 <label id="lcontribwidget" for="tab3">Contrib Widgets</label>

			 <input id="tab4" type="radio" name="tabs">
			 <label id="lliverep" for="tab4">Live Rep</label>

			 <section id="content1">
				<div class="vtab">
					<h3>Footer Short Code</h3>
					<div class="col-md-12">
						
						<p>
						Please add this to your footer.php - &lt;?php echo do_shortcode( '[contrib_footer]'); ?&gt;
						
						</p>
					</div>
				</div>
			 </section>

			 <section id="content2">
				<div class="vtab">
				   <h3>Manage Pages</h3>
				   <div class="row">
					 <ul class="list-unstyled mpages">
						<?php
							$pages = [
								['Contact','contact',$activate_contact_page],
								['Developers','developers',$activate_developers_page],
								['Partner','partner',$activate_partner_page],
								['Privacy','privacy',$activate_privacy_page],
								['Referral','referral',$activate_referral_page],
								['Staffing','staffing',$activate_staffing_page],
								['Terms','terms',$activate_terms_page],
								['About','about',$activate_about_page]
							];
							foreach($pages as $page ){
						?>
							<li class="col-md-2 text-center">
							   <div class="mpages-in">
								<?php
									if(!empty($page[2])){
										?>
										<a class="link" href="<?=get_permalink($page[2])?>"><h4><?=$page[0]?></h4></a>
										<?php
									}else{
										?>
										<a class="link" href="javascript:;"><h4><?=$page[0]?></h4></a>
										<?php
									}
								?>
									<a data-page="<?=$page[1]?>" style="<?=empty($page[2])?'display:none':''?>" data-target="#frm_activate_<?=$page[1]?>_page" href="javascript:;" class="btn btn-primary vnoc_remove_page">Remove</a>
									<a data-page="<?=$page[1]?>" style="<?=!empty($page[2])?'display:none':''?>" data-target="#frm_activate_<?=$page[1]?>_page" href="javascript:;" class="btn btn-primary vnoc_add_page">Add</a>
									<!--<a href="javascript:;" class="btn btn-default">Edit</a>-->
							   </div>
							</li>
						<?php
							}
						?>
					 </ul>
					 <script type="text/javascript">
						jQuery(document).ready(function(){									
							jQuery('.vnoc_add_page').click(function(){
								var parent = jQuery(this).parent();
								var b = jQuery(this);
								b.attr('disabled', 'disabled').html("Adding...");
								jQuery.post(
									"<?=get_site_url()?>/wp-admin/admin-ajax.php", 
									{
										action: 'savepage',
										add: 1,
										page: jQuery(this).attr('data-page')
									}, 
									function(response){
										parent.find('.vnoc_remove_page').show();
										parent.find('.vnoc_add_page').hide();
										b.removeAttr('disabled').html('Add');
										b.parent().find('.link').attr('href',response);
									}
								);
							});
							
							jQuery('.vnoc_remove_page').click(function(){
								if(confirm('Are you sure you want to delete this page?')){
									var parent = jQuery(this).parent();
									var b = jQuery(this);
									b.attr('disabled', 'disabled').html("Deleting...");
									jQuery.post(
										"<?=get_site_url()?>/wp-admin/admin-ajax.php", 
										{
											action: 'savepage',
											add: 0,
											page: jQuery(this).attr('data-page')
										}, 
										function(response){
											parent.find('.vnoc_add_page').show();
											parent.find('.vnoc_remove_page').hide();
											b.removeAttr('disabled').html('Remove');
											b.parent().find('.link').attr('href','javascript:;');
										}
									);
								}
							});
						});
						</script>
				   </div>
				</div>
			 </section>

			 <section id="content3">
				<div class="vtab">
				   <h3>Manage Contrib Widgets</h3>
				   <div class="row">
					 <div class="col-md-4 text-center">
						<h4>Lead Widget</h4>
						<p>This widget allows you to collect your leads and allow you to integrate into your favorite newsletter or lead management system.
						<br><a target="_blank" href="http://contrib.applications.com/apps/details/m/leadwidget" class="btn btn-primary btn-sm">
						<b>View More</b>
						</a>	
						</p>
						<p><img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/uploads/apps-lead-widget2.png" style="display: inline-block;"></p>
						<div class="scode-box">
						   <div class="row">
								<div class="col-md-12">
									<p>Short Code</p>
								</div>
							  <div class="col-md-6">
								 <p>Lead Widget Black</p>
								 <p>[lead_contrib_widget_black]</p>
							  </div>
							  <div class="col-md-6">
								 <p>Lead Widget Gray</p>
								 <p>[lead_contrib_widget_gray]</p>
							  </div>
						   </div>
						</div>
					 </div>

					 <div class="col-md-4 text-center">
						<h4>Micro News Widget</h4>
						<p>Create an easy update ticker on your site that you could post to your social sites for free.
						<br><a target="_blank" href="http://contrib.applications.com/apps/details/m/micronews" class="btn btn-primary btn-sm">
						<b>View More</b>
						</a>	
						</p>
						<p><img class="img-responsive" src="https://rdbuploads.s3.amazonaws.com/vnoc/apps_marketplace/apps-micronews.png" style="display: inline-block;"></p>
						<div class="scode-box">
						   <div class="row">
								<div class="col-md-12">
									<p>Short Code</p>
									<p>[contrib_micronews]</p>
								</div>
						   </div>
						</div>
					 </div>
				   
					 <div class="col-md-4 text-center">
						<h4>Rating Widget</h4>
						<p>Create an easy rating widget on any page for free..
						<br><a target="_blank" href="http://contrib.applications.com/apps/details/m/rating" class="btn btn-primary btn-sm">
						<b>View More</b>
						</a>	
						</p>
						<p><img class="img-responsive" src="https://rdbuploads.s3.amazonaws.com/vnoc/apps_marketplace/apps-rating.png" style="display: inline-block;"></p>
						<div class="scode-box">
						   <div class="row">
								<div class="col-md-12">
									<p>Short Code</p>
									<p>[contrib_rating]</p>
								</div>
						   </div>
						</div>
					 </div>
					 
					 
					 
					 <div class="col-md-4 text-center">
						<h4>Sidebar Widget</h4>
						<p>This widget allows you to share brands needs to your visitor

						</p>
						<p style="padding:10px;" class="text-muted">The Sharing Sidebar is the easiest way to increase sharing up to 2x over regular sharing buttons. It floats over the side of your page and automatically shows visitors the right sharing buttons for them.
							<br><a target="_blank" href="http://contrib.applications.com/apps/details/m/cwsidebar" class="btn btn-primary btn-sm">
							<b>View More</b>
						</a>
						</p>
						<p><img class="img-responsive" src="https://s3.amazonaws.com/assets.zipsite.net/images/lucille/sidebar-contrib-widget.png" style="display: inline-block;"></p>
						<div class="scode-box">
						   <div class="row">
							  <div class="col-md-12">
								 <div class="scw">
								   <input <?=!empty($activate_upper_right_contrib_widget)?'checked' :''?> style="display:inline;" value="" id="side-contrib-widget" type="checkbox">
								   <label id="lbl-side-contrib-widget" class="lbl-chk" for="side-contrib-widget">Activate</label>
								 </div>
							  </div>
						   </div>
						</div>
					 </div>
					 
					 
					 <div class="col-md-4 text-center">
						<h4>Upper Right Widget</h4>
						<p>This widget allows you to share brands needs to your visitor
						
						</p>
						<p style="padding:10px;" class="text-muted">The Sharing Sidebar is the easiest way to increase sharing up to 2x over regular sharing buttons. It floats over the side of your page and automatically shows visitors the right sharing buttons for them.
						<br><a target="_blank" href="http://contrib.applications.com/apps/details/m/cwupper" class="btn btn-primary btn-sm">
							<b>View More</b>
						</a>
						</p>
						<p><img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/images/lucille/thumb-top-right.png" style="display: inline-block;"></p>
						<div class="scode-box">
						   <div class="row">
							  <div class="col-md-12">
								 <div class="scw">
								   <input <?=!empty($activate_sidebar_contrib_widget)?'checked' :''?> style="display:inline;" value="" id="uprtop-contrib-widget"  type="checkbox">
								   <label id="lbl-uprtop-contrib-widget" class="lbl-chk" for="uprtop-contrib-widget">Activate</label>
								 </div>
							  </div>
						   </div>
						</div>
					 </div>
					 
				   </div>
				   
				</div>
			 </section>

			 <section id="content4">
				<div class="vtab">
				   <h3>Contrib Live Rep</h3>
				   <div class="row">
					 <div class="col-md-3 text-center">
						<p>Contrib Live Rep allows you to create a live chat discussion on your site for your visitors.
						<br> <a target="_blank" href="http://contrib.applications.com/apps/details/m/liverep" class="btn btn-primary btn-sm">
						<b>View More</b>
					</a>
						</p>
						<p><img class="img-responsive" src="https://d2qcctj8epnr7y.cloudfront.net/uploads/apps-liverep.jpg"></p>
						<div class="scode-box">
						   <div class="row">
							  <div class="col-md-12">
								 <p>Short Code</p>
								 <p>[contrib_live_rep]</p>
							  </div>
						   </div>
						</div>
					 </div>
				   </div>
				</div>
			 </section>
		  </div>
		   <!-- end tab-->
		</div>
		<br style="clear:both;">
		<script>
			jQuery(document).ready(function(){
				jQuery('a.vcp-box').click(function(){
					jQuery(jQuery(this).attr('data-target')).trigger('click');
				});

				jQuery('#side-contrib-widget').change(function(){
					activateSidebaWidget();
				});
				
				function activateSidebaWidget()
				{
					var b = jQuery('#lbl-side-contrib-widget');
					var check = jQuery('#side-contrib-widget').is(':checked');
					if(check){
						b.attr('disabled', 'disabled').html("Activating...");
					}else{
						b.attr('disabled', 'disabled').html("Deactivate...");
					}
					
					jQuery.post(
						"<?=get_site_url()?>/wp-admin/admin-ajax.php", 
						{
							action: 'activatesidebarwidget',
							value: jQuery('#side-contrib-widget').is(':checked')?1:0,
						}, 
						function(response){
							b.removeAttr('disabled').html("Activate");
						}
					);
				}
				
				jQuery('#uprtop-contrib-widget').change(function(){
					activateUpperRigthWidget();
				});
				
				function activateUpperRigthWidget()
				{
					var b = jQuery('#lbl-uprtop-contrib-widget');
					var check = jQuery('#uprtop-contrib-widget').is(':checked');
					if(check){
						b.attr('disabled', 'disabled').html("Activating...");
					}else{
						b.attr('disabled', 'disabled').html("Deactivate...");
					}
					
					jQuery.post(
						"<?=get_site_url()?>/wp-admin/admin-ajax.php", 
						{
							action: 'activateuppersidebarwidget',
							value: jQuery('#uprtop-contrib-widget').is(':checked')?1:0,
						},
						function(response){
							b.removeAttr('disabled').html("Activate");
						}
					);
				}
			});
		</script>
	<?php
	}
	
	public function create_pages($title,$slug,$template)
	{
		$post_id = 0;
		$_page_check = get_page_by_title($title);
		$_page = array(
			'post_type' => 'page',
			'post_title' => $title,
			'post_content' => '',
			'post_status' => 'publish',
			'post_author' => 1,
			'post_slug' => $slug
		);
		if(!isset($_page_check->ID) && !$this->the_slug_exists($slug)){
			$post_id = wp_insert_post($_page);
			update_post_meta( $post_id, '_wp_page_template', $template );
		}else{
			$post_id = $_page_check->ID;
		}
		return $post_id;
	}

	public function the_slug_exists($post_name) {
		global $wpdb;
		if($wpdb->get_row("SELECT post_name FROM wp_posts WHERE post_name = '" . $post_name . "'", 'ARRAY_A')) {
			return true;
		} else {
			return false;
		}
	}
		
	public function lead_contrib_widget_black_script($atts, $content = null) {
		$html = '<script src="https://manage.vnoc.com/widgets/leads?domain='.$_SERVER['SERVER_NAME'].'&c=black"></script>';
		return $html;
	}

	public function lead_contrib_widget_gray_script($atts, $content = null) {
		$html = '<script src="https://manage.vnoc.com/widgets/leads?domain='.$_SERVER['SERVER_NAME'].'&c=gray"></script>';
		return $html;
	}
	
	public function contrib_live_rep_script($atts, $content = null) {
		$html = '<div id="chat_content" data="'.$_SERVER['SERVER_NAME'].'"></div>'.
			'<script type="text/javascript" src="https://tools.contrib.com/js/chat.js"></script>';
		return $html;
	}
	
	public function contrib_micronews_script($atts, $content = null) {
		$html = '<script type="text/javascript" src="https://contrib.com/widgets?ma=micronews&dn='.$_SERVER['SERVER_NAME'].'"></script>';
		return $html;
	}
	
	public function contrib_rating_script($atts, $content = null) {
		$html = '<script type="text/javascript" src="https://www.contrib.com/widgets?ma=rating"></script>';
		return $html;
	}

	public function contrib_footer_content($atts, $content = null) {
		$file = plugin_dir_path(__FILE__). get_post_meta($post->ID, '_wp_page_template', true);
		
		$file = $file.'footer.php';
		if ( file_exists( $file ) ) {
			return file_get_contents($file);
		} else {
			return 'Missing footer file.';
		}
	}
	
	public function do_upper_right_contrib_widget(){
		echo '  <script src="https://tools.contrib.com/cwidget?d='.$_SERVER['SERVER_NAME'].'&p=ur&c=f"></script>    ';
	}
	
	
	public function do_sidebar_contrib_widget(){
	   echo ' <script src="https://tools.contrib.com/cwidget?d='.$_SERVER['SERVER_NAME'].'&p=sb&c=f"></script>  ';
	}
	
	public function jquery_no_conflict()
	{
		echo ' <script>var $ = jQuery.noConflict();</script>  ';
	}
}

add_action( 'plugins_loaded', array( 'VNOCUltimate', 'get_instance' ) );

//add_action('wp_loaded', 'add_pages');