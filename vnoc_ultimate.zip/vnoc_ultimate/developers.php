<?php get_header(); ?>
<style>
#content-footer-section {
    display: none;
}
.return-container {
   margin-top:20px;
   margin-bottom: 40px;
}
.pc-box {
    background: #fafafa;
    padding: 80px 30px 100px 30px;
    margin-bottom: 50px;
}
</style>

<div class="container">
   <div class="row">
      <div class="col-md-12 text-center return-container">
         <a href="/" class="btn btn-primary btn-lg">Return to Hompage</a>
      </div>
      <hr>
      <div class="col-md-12">
         <h3 class="ptitle text-center">
            Developers
         </h3>
      </div>
      <div class="col-md-8 col-md-offset-2 pc-box">
			<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Do you have code or an app that could run this brand? <?=$_SERVER['HTTP_HOST']?> is connected with Contrib. </h4>
			<p></p>
			<h4><i class="fa fa-code" aria-hidden="true"></i>&nbsp;Contrib is the new way to contribute and get equity building the world's biggest brands and startups. We have our own Developers platform, and we run the world's best brands on them. Do you have an app, or code that could help run <?=$_SERVER['HTTP_HOST']?> </h4>
			<p class="text-center">
			<br>
			<a href="/contact" class="btn btn-default btn-lg">Inquire Here</a>
      </div>
   </div>
</div>
<?php get_footer(); ?>
