<h2>WordPress Page Templater by Harri Bell-Thomas</h2>

A useful bit of code from <a href="https://github.com/HarriBellThomas">Harri Bell-Thomas</a> you can use to dynamically create WordPress Page Templates with PHP.

Read the full tutorial on <a href="http://www.wpexplorer.com/wordpress-page-templates-plugin" title="Adding Page Templates to WordPress with a Plugin">how to add Page Templates to WordPress with a plugin</a>
