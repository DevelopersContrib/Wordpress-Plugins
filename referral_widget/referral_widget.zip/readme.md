Referral widget - 
Instruction: 
1. Download and install as a plugin.
2. Signup or Login
3. Select Brand
4. Create your campaign ->  referrals.com
5. Choose campaign, copy/paste shortcode

